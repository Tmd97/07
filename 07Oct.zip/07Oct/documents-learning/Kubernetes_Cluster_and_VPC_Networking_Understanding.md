# Kubernetes Cluster and AWS VPC Networking Understanding

## Purpose

This document captures the foundational understanding of:

- A practical self-managed Kubernetes cluster on Amazon EC2
- How worker nodes join the control plane
- How EC2 instances communicate inside an AWS VPC
- How packet routing and route lookup work

---

## 1. Practical Kubernetes Cluster Setup

For a self-managed cluster with **one control-plane node and two worker nodes**, use three EC2 instances:

```text
AWS VPC: 10.0.0.0/16

EC2-1: Control plane   Private IP: 10.0.1.10
EC2-2: Worker node 1  Private IP: 10.0.1.11
EC2-3: Worker node 2  Private IP: 10.0.1.12
```

```text
                 EC2-1
             Control Plane
          API Server :6443
                  |
        +---------+---------+
        |                   |
      EC2-2               EC2-3
    Worker Node 1       Worker Node 2
```

Each node is a separate Linux machine. The nodes communicate using their VPC private IP addresses.

### Software installed on all nodes

Each machine normally needs:

- A container runtime such as `containerd`
- `kubelet`
- `kubeadm`

`kubectl` is required wherever cluster administration commands will be executed. It is commonly configured on the control-plane node and administrator workstations, but it is not required for a worker node to run workloads.

### Role-specific components

#### Control-plane node

After `kubeadm init`, the control-plane node runs components such as:

- kube-apiserver
- kube-scheduler
- kube-controller-manager
- etcd, for a stacked-etcd kubeadm setup
- kubelet

#### Worker nodes

After `kubeadm join`, a worker node runs:

- kubelet
- container runtime
- kube-proxy, when the chosen cluster networking setup uses it
- application Pods assigned to that node

The control-plane components are not installed as active control-plane services on an ordinary worker node.

### Learning setup versus enterprise production

A `1 control plane + 2 workers` topology is useful for learning and non-critical environments. However, the single control plane is a failure point. A highly available self-managed production design normally uses multiple control-plane nodes behind a stable control-plane endpoint and an odd number of etcd members, commonly three.

The exact production node count depends on availability, capacity, failure-domain, recovery, security, and cost requirements.

---

## 2. Creating the Cluster

### Step 1: Prepare every EC2 instance

Before Kubernetes setup:

1. Place the EC2 instances in a VPC with network connectivity between them.
2. Configure security groups and network ACLs to permit required cluster traffic.
3. Install the container runtime, kubelet, and kubeadm.
4. Ensure hostnames, time synchronization, operating-system settings, and Kubernetes version compatibility are correct.

### Step 2: Initialize the control plane

Run on EC2-1:

```bash
sudo kubeadm init --apiserver-advertise-address=10.0.1.10
```

A real command may also specify options such as a stable control-plane endpoint and the Pod-network CIDR required by the selected CNI plugin.

The API server listens on a network address and normally uses TCP port `6443`.

### Step 3: Install a CNI plugin

After control-plane initialization, install a compatible CNI plugin such as Calico, Cilium, or Flannel. Kubernetes needs a Pod network before normal cross-node Pod communication can work.

### Step 4: Join the workers

`kubeadm init` prints a command similar to:

```bash
sudo kubeadm join 10.0.1.10:6443 \
  --token <bootstrap-token> \
  --discovery-token-ca-cert-hash sha256:<ca-public-key-hash>
```

Run it separately on EC2-2 and EC2-3.

---

## 3. What `kubeadm join` Does

The worker does not discover the control plane magically. The join command explicitly gives it the control-plane API endpoint:

```text
10.0.1.10:6443
```

The fields have these meanings:

- `10.0.1.10`: private IP or stable DNS name of the control-plane endpoint
- `6443`: Kubernetes API server port
- `--token`: temporary bootstrap credential
- `--discovery-token-ca-cert-hash`: pins the cluster CA public key so the worker can verify that it reached the intended control plane

### Simplified join sequence

```text
Worker EC2-2
    |
    | HTTPS connection to 10.0.1.10:6443
    v
API Server on EC2-1
```

Conceptually, `kubeadm join` performs the following:

1. Runs preflight checks on the worker.
2. Connects to the API server endpoint supplied in the command.
3. Uses token-based discovery and validates the control-plane CA using the supplied hash.
4. Creates a local key pair and uses the bootstrap token to request a kubelet client certificate.
5. Receives the approved certificate and writes kubelet configuration on the worker.
6. Starts or configures kubelet so it continues communicating with the API server.
7. kubelet registers the machine as a Kubernetes Node.

After the join operation, kubelet remembers the API server through its generated kubeconfig, commonly located at:

```text
/etc/kubernetes/kubelet.conf
```

That kubeconfig contains the API server address and certificate-based client credentials. The bootstrap token is not the worker's permanent day-to-day identity.

### Continuing communication

After joining, kubelet communicates with the API server over HTTPS to:

- Register and update the Node object
- Report node and Pod status
- Watch for Pods assigned to that node
- Retrieve the desired Pod specifications

A more accurate statement than "the worker asks whether there are Pods for it every few seconds" is that kubelet uses Kubernetes API operations, including watches and status updates, to reconcile the desired state assigned to its node.

---

## 4. EC2 Instances Inside a VPC

A VPC is a logically isolated virtual network in AWS. Its CIDR block provides address space from which subnet ranges and EC2 private IP addresses are allocated.

Example:

```text
VPC CIDR:       10.0.0.0/16
Subnet A CIDR:  10.0.1.0/24

EC2-1: 10.0.1.10
EC2-2: 10.0.1.11
EC2-3: 10.0.1.12
```

Being inside the same VPC provides a routing path through the VPC's local route, but it does **not by itself guarantee successful communication**. Traffic must also be allowed by relevant security groups, network ACLs, host firewalls, and listening applications.

For example, EC2-2 can reach the API server only if:

- Its subnet has a route for the destination
- EC2-1's security group allows TCP `6443` from the intended worker-node source
- Network ACLs permit the traffic and return traffic
- The host firewall permits it
- kube-apiserver is listening on the expected address and port

### Private communication does not need the internet

When EC2-2 contacts EC2-1 using the private address `10.0.1.10`, the traffic remains on AWS's private VPC networking path. It does not need an Internet Gateway or NAT Gateway.

---

## 5. How Packet Transfer and Routing Work

Suppose EC2-2 runs:

```bash
curl -k https://10.0.1.10:6443
```

The destination is the API server on EC2-1.

### Packet flow overview

```text
Process: curl
   |
   v
EC2-2 Linux networking stack
   |
   | route lookup for 10.0.1.10
   v
Primary network interface (for example, eth0/ens5)
   |
   v
EC2 virtual network interface (ENI)
   |
   v
AWS VPC networking fabric and implicit VPC router
   |
   v
EC2-1 ENI
   |
   v
EC2-1 Linux networking stack
   |
   v
kube-apiserver listening on TCP 6443
```

The machines are not connected by a dedicated physical cable. AWS's virtual networking fabric delivers traffic between their elastic network interfaces.

---

## 6. Route Lookup in Detail

There are two useful routing viewpoints:

1. The source EC2 instance's Linux routing decision
2. The AWS subnet/VPC routing decision

### 6.1 Linux route lookup on EC2-2

EC2-2's kernel examines the destination IP and selects a route. You can inspect the decision with:

```bash
ip route get 10.0.1.10
```

You can inspect the route table with:

```bash
ip route
```

A simplified output might look like:

```text
default via 10.0.1.1 dev eth0
10.0.1.0/24 dev eth0 proto kernel scope link src 10.0.1.11
```

The kernel uses **longest-prefix matching**. It selects the most specific matching route.

For destination `10.0.1.10`:

- `10.0.1.0/24` matches
- `0.0.0.0/0` also matches
- `/24` is more specific than `/0`
- Therefore, the packet is sent using `eth0`

On EC2, details such as the apparent gateway and neighbor handling are implemented by AWS virtualization. The important model is that the guest operating system sends the packet through its ENI toward the VPC network.

### 6.2 AWS subnet route-table lookup

Every subnet is associated with one route table. AWS route tables contain destination-to-target rules.

A VPC route table includes a local route such as:

```text
Destination   Target
10.0.0.0/16  local
```

Because `10.0.1.10` belongs to `10.0.0.0/16`, the `local` route matches. AWS then delivers the packet through the VPC network to the ENI that owns `10.0.1.10`.

If several routes match a destination, AWS also uses the most specific route, known as longest-prefix match.

### 6.3 Security checks

Routing determines **where traffic should go**. It does not decide whether traffic is permitted.

The flow is also evaluated against controls such as:

- Source and destination security groups
- Network ACLs for the relevant subnets
- Operating-system firewall rules

Security groups are stateful. Network ACLs are stateless, so their inbound and outbound rules must account for both directions.

### 6.4 Destination processing

When the packet reaches EC2-1:

1. EC2-1's network stack sees that the destination IP belongs to a local interface.
2. TCP processing checks destination port `6443`.
3. If kube-apiserver is listening and the connection is permitted, the TCP and TLS handshakes proceed.
4. The API server authenticates and authorizes the Kubernetes request.
5. Response packets return to EC2-2 through the corresponding network path.

---

## 7. Same Subnet Versus Different Subnets

### Same subnet

```text
EC2-1: 10.0.1.10/24
EC2-2: 10.0.1.11/24
```

The guest operating system sees the destination as reachable through its local network interface. AWS's virtual network resolves and delivers the traffic to the destination ENI.

### Different subnets in the same VPC

```text
EC2-1: 10.0.1.10 in subnet 10.0.1.0/24
EC2-2: 10.0.2.11 in subnet 10.0.2.0/24
VPC:   10.0.0.0/16
```

The source sends toward its virtual gateway, and the VPC's `10.0.0.0/16 -> local` route permits routing between the subnets. Security controls must still allow the traffic.

### Traffic outside the VPC

A destination outside the VPC normally needs another route target, for example:

```text
0.0.0.0/0 -> Internet Gateway   # public-subnet internet routing
0.0.0.0/0 -> NAT Gateway        # private-subnet outbound IPv4
10.20.0.0/16 -> VPC Peering
10.30.0.0/16 -> Transit Gateway
```

These routes are not needed for private-IP communication between instances covered by the same VPC local route.

---

## 8. Important Corrections to Keep in Mind

### Correction 1: VPC is not an IP address

A VPC has one or more CIDR blocks. EC2 network interfaces receive IP addresses from subnet ranges inside those CIDR blocks.

### Correction 2: Same VPC does not automatically mean allowed

The route may exist while security groups, network ACLs, host firewalls, or the application still block the connection.

### Correction 3: Routing and firewalling are different

- Routing decides the next path or target.
- Firewall and security rules decide whether the packet is allowed.

### Correction 4: kube-proxy is not generally part of the control-plane component list

`kube-proxy` is normally deployed as a DaemonSet and runs on nodes according to cluster configuration. It is not a control-plane service like kube-apiserver, scheduler, or controller-manager.

### Correction 5: Service rules are not ordinary Linux route-table entries

In common kube-proxy modes, Kubernetes Service forwarding is implemented using packet-processing rules such as iptables, nftables, or IPVS-related mechanisms. The normal Linux routing table then helps route the translated packet toward the selected Pod IP. Therefore:

```text
Service definition
    -> EndpointSlices
    -> kube-proxy or another dataplane implementation
    -> packet translation/forwarding rules
    -> normal routing toward the Pod network
```

This is more accurate than saying a Service directly creates standard routing-table entries.

---

## 9. Useful Verification Commands

### On the control plane

```bash
sudo ss -lntp | grep 6443
kubectl get nodes -o wide
kubectl get pods -A -o wide
```

### On a worker

```bash
ip addr
ip route
ip route get 10.0.1.10
curl -k https://10.0.1.10:6443
sudo systemctl status kubelet
sudo journalctl -u kubelet
sudo cat /etc/kubernetes/kubelet.conf
```

A response such as `401 Unauthorized` or `403 Forbidden` from an unauthenticated API request can still prove that the network and TLS endpoint are reachable. A timeout generally points toward routing, security controls, firewall rules, or an unavailable listener.

---

## 10. Final Mental Model

```text
Kubernetes layer
Worker kubelet knows API endpoint from kubeadm join/kubeconfig
                    |
                    v
Transport layer
HTTPS over TCP, usually destination port 6443
                    |
                    v
EC2 host networking
Linux kernel performs route lookup and sends through ENI
                    |
                    v
AWS networking
Subnet route table selects VPC local route
                    |
                    v
Security layer
Security groups, NACLs, and host firewall allow or deny
                    |
                    v
Destination
Packet reaches kube-apiserver on the control-plane EC2 instance
```

The essential idea is:

> Kubernetes components on different machines communicate using ordinary IP networking. `kubeadm join` supplies the API server endpoint and establishes trust; Linux and AWS VPC routing deliver the packets; security controls decide whether those packets are allowed.

---

## References

- Kubernetes documentation: `https://kubernetes.io/docs/setup/production-environment/tools/kubeadm/create-cluster-kubeadm/`
- Kubernetes `kubeadm join` reference: `https://kubernetes.io/docs/reference/setup-tools/kubeadm/kubeadm-join/`
- AWS VPC route-table concepts: `https://docs.aws.amazon.com/vpc/latest/userguide/RouteTables.html`
- AWS subnet route tables: `https://docs.aws.amazon.com/vpc/latest/userguide/subnet-route-tables.html`
