package com.forvmom.common.errorhandler;

import org.springframework.http.HttpStatus;

public class NotAllowedCustomException extends RuntimeException{

    private final HttpStatus status;

    public NotAllowedCustomException(String message) {
        this(message, HttpStatus.FORBIDDEN);
    }

    public NotAllowedCustomException(String message, HttpStatus status) {
        super(message);
        this.status = status;
    }

    public HttpStatus getStatus() {
        return status;
    }
}
